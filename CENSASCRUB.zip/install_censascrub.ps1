<#
.SYNOPSIS
 Installs dependencies, copies the script to %USERPROFILE%\CENSASCRUB, and creates a desktop launcher.
#>

# 1) Ensure Conda/Python are available
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) {
    Write-Error 'Conda not found – please install Miniconda first.'; exit 1
}
$python = (Get-Command python).Path
if (-not $python) {
    Write-Error 'Python not found in PATH.'; exit 1
}

# 2) Install Python packages
Write-Output 'Installing pandas, numpy, openpyxl…'
pip install pandas numpy openpyxl

# 3) Create target folder
$targetDir = Join-Path $env:USERPROFILE 'CENSASCRUB'
if (-not (Test-Path $targetDir)) {
    New-Item -Path $targetDir -ItemType Directory | Out-Null
}

# 4) Copy the script
Copy-Item -Path (Join-Path $PSScriptRoot 'censascrub_v001.py') -Destination $targetDir -Force

# 5) Generate launcher batch on Desktop
$desktop = [Environment]::GetFolderPath('Desktop')
$batPath = Join-Path $desktop 'START_SCRUBBING.bat'
@"
@echo off
REM — Activate base Conda environment
call "%USERPROFILE%\Miniconda3\Scripts\activate.bat"

REM — Run CensaScrub
python "%USERPROFILE%\CENSASCRUB\censascrub_v001.py"

REM — Pause to show any errors
pause
"@ | Out-File -FilePath $batPath -Encoding ASCII -Force

Write-Output "Installation complete. Launcher created at $batPath"
