#!/usr/bin/env python3
"""
Excel File Processor for Insurance Data (MASTER CENSUS Only)
"""

import pandas as pd
import numpy as np
import re
import os
import sys
from datetime import datetime
from typing import Dict, List, Tuple
import string
import glob

# --- Excel-style column letter labels (A, B, ..., Z, AA, AB, ...) ---
def excel_col_label(n):
    label = ''
    while n >= 0:
        label = chr(n % 26 + ord('A')) + label
        n = n // 26 - 1
    return label

# --- File picker utilities ---
def get_recent_excel_files(folder, limit=20):
    files = glob.glob(os.path.join(folder, '**', '*.xls*'), recursive=True)
    files = [(f, os.path.getmtime(f)) for f in files if os.path.isfile(f)]
    files.sort(key=lambda x: x[1], reverse=True)
    return [f[0] for f in files[:limit]]

def pick_file_interactive(base_folder):
    while True:
        print(f"\nListing recent Excel files in: {base_folder}")
        excel_files = get_recent_excel_files(base_folder)
        subfolders = [f for f in os.listdir(base_folder) if os.path.isdir(os.path.join(base_folder, f))]
        for i, f in enumerate(excel_files):
            print(f"{i + 1}. {os.path.relpath(f, base_folder)}")
        if subfolders:
            print("\nFolders:")
            for i, f in enumerate(subfolders):
                print(f"F{i + 1}. {f}")
        choice = input("\nEnter number to select file, F# to enter folder, or Q to quit: ").strip().upper()
        if choice == 'Q':
            return None
        if choice.startswith('F') and choice[1:].isdigit():
            folder_idx = int(choice[1:]) - 1
            if 0 <= folder_idx < len(subfolders):
                base_folder = os.path.join(base_folder, subfolders[folder_idx])
                continue
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(excel_files):
                return excel_files[idx]
        print("Invalid selection. Try again.")

def get_file_path_interactive():
    downloads = os.path.join(os.path.expanduser("~"), "Downloads")
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    print("\nNo file path provided.")
    options = []
    if os.path.isdir(downloads):
        options.append(("1", "List recent Excel files in Downloads", downloads))
    if os.path.isdir(desktop):
        options.append(("2", "List recent Excel files in Desktop", desktop))
    options.append(("3", "Enter full path manually", None))
    for num, text, _ in options:
        print(f"{num}. {text}")
    valid_choices = {num: folder for num, _, folder in options}
    while True:
        choice = input(f"Choose option ({'/'.join(valid_choices.keys())}): ").strip()
        if choice in valid_choices and valid_choices[choice]:
            file = pick_file_interactive(valid_choices[choice])
            if file: return file
        elif choice == "3":
            manual = input("Enter full path to the Excel file: ").strip('"').strip()
            if os.path.isfile(manual): return manual
            print("File not found. Try again.")
        else:
            print("Invalid choice. Try again.")


class ExcelProcessor:
    MASTER_CENSUS_COLUMNS = {
        'EMPLOYEE INFORMATION': [
            'Relationship', 'Status Field', 'Social Security Number', 'Member Last Name',
            'First Name', 'Middle Initial', 'Gender', 'Date of Birth', 'Disabled'
        ],
        'CONTACT INFORMATION': [
            'Date of Hire', 'Member Street Address', 'City', 'State', 'Zip', 'Phone', 'Email'
        ],
        'BENEFITS INFORMATION': {
            'Dental Coverage': [
                'Dental Plan Election', 'Dental Coverage Type', 'DHMO Provider Name',
                'Dental Prior Carrier Name', 'Dental Prior Carrier Effective Date',
                'Dental Prior Carrier Term Date', 'Dental Prior Carrier Ortho'
            ],
            'Vision Coverage': [
                'Vision Plan Election', 'Vision Coverage Type'
            ],
            'Life Coverage': [
                'Basic Life Coverage Type', 'Primary Life Beneficiary',
                'Dependent Basic Life', 'Life/AD&D Class'
            ],
            'Voluntary Life': [
                'Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life'
            ],
            'Disability Coverage': [
                'STD', 'LTD', 'STD Class', 'LTD Class'
            ],
            'Compensation': [
                'Salary Type', 'Salary Amount', 'Occupation', 'Hours Worked',
                'Working Location', 'Billing Division'
            ]
        }
    }
    FLAT_MASTER_CENSUS_COLUMNS = []
    for category, columns in MASTER_CENSUS_COLUMNS.items():
        if isinstance(columns, list):
            FLAT_MASTER_CENSUS_COLUMNS.extend(columns)
        elif isinstance(columns, dict):
            for subcategory, subcols in columns.items():
                FLAT_MASTER_CENSUS_COLUMNS.extend(subcols)

    VALID_VALUES = {
        'Relationship': ['Employee', 'Spouse', 'Domestic Partner', 'Child'],
        'Status Field': ['Active', 'COBRA', 'Retiree'],
        'Gender': ['M', 'F'],
        'Disabled': ['Yes', 'No'],
        'Dental Coverage Type': ['EE', 'ES', 'EC', 'EF', 'W'],
        'Vision Coverage Type': ['EE', 'ES', 'EC', 'EF', 'W'],
        'Basic Life Coverage Type': ['EE', 'W'],
        'Dependent Basic Life': ['Enroll', 'W'],
        'STD': ['EE', 'W'],
        'LTD': ['EE', 'W'],
        'Salary Type': ['Annual', 'Hourly'],
        'Dental Prior Carrier Ortho': ['Yes', 'No']
    }
    USPS_ABBREVIATIONS = {
        'AVENUE': 'AVE', 'BOULEVARD': 'BLVD', 'CIRCLE': 'CIR', 'COURT': 'CT',
        'DRIVE': 'DR', 'EXPRESSWAY': 'EXPY', 'FREEWAY': 'FWY', 'HIGHWAY': 'HWY',
        'LANE': 'LN', 'PARKWAY': 'PKWY', 'PLACE': 'PL', 'ROAD': 'RD',
        'SQUARE': 'SQ', 'STREET': 'ST', 'TERRACE': 'TER', 'WAY': 'WAY',
        'NORTH': 'N', 'SOUTH': 'S', 'EAST': 'E', 'WEST': 'W',
        'NORTHEAST': 'NE', 'NORTHWEST': 'NW', 'SOUTHEAST': 'SE', 'SOUTHWEST': 'SW',
        'APARTMENT': 'APT', 'BUILDING': 'BLDG', 'DEPARTMENT': 'DEPT', 'FLOOR': 'FL',
        'ROOM': 'RM', 'SUITE': 'STE', 'UNIT': 'UNIT'
    }

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.excel_file = None
        self.sheet_names = []
        self.master_census_df = None
        self.column_mapping = {}
        self.processed_master_census = None

    def load_excel_file(self) -> bool:
        try:
            self.excel_file = pd.ExcelFile(self.file_path, engine='openpyxl')
            self.sheet_names = self.excel_file.sheet_names
            print(f"Loaded Excel file with sheets: {', '.join(self.sheet_names)}")
            return True
        except Exception as e:
            print(f"Error loading Excel file: {e}")
            return False

    def analyze_sheets(self) -> str:
        # Try to automatically find a master census sheet
        sheet_candidates = []
        for sheet_name in self.sheet_names:
            if sheet_name.upper() == 'MASTER CENSUS':
                return sheet_name
            if 'CENSUS' in sheet_name.upper() or 'MASTER' in sheet_name.upper():
                sheet_candidates.append(sheet_name)
        if sheet_candidates:
            print("\nMultiple possible sheets found:")
            for i, name in enumerate(sheet_candidates):
                print(f"  {i + 1}. {name}")
            while True:
                entry = input(f"Select sheet number (1-{len(sheet_candidates)}), or 0 to choose from all sheets: ").strip()
                if entry.isdigit():
                    entry = int(entry)
                    if entry == 0:
                        break
                    if 1 <= entry <= len(sheet_candidates):
                        return sheet_candidates[entry - 1]
        # Present all available sheets
        print("\nAvailable sheets:")
        for i, name in enumerate(self.sheet_names):
            print(f"  {i + 1}. {name}")
        while True:
            entry = input(f"Select sheet number (1-{len(self.sheet_names)}): ").strip()
            if entry.isdigit():
                entry = int(entry)
                if 1 <= entry <= len(self.sheet_names):
                    return self.sheet_names[entry - 1]
            print("Invalid selection. Try again.")


    def load_sheet(self, master_census_sheet: str) -> None:
        self.master_census_df = pd.read_excel(self.excel_file, sheet_name=master_census_sheet)
        self.master_census_df.columns = self.master_census_df.columns.map(str)
        self.master_census_df = self.master_census_df.loc[:, ~self.master_census_df.columns.str.contains('^Unnamed')]
        print(f"MASTER CENSUS sheet has {len(self.master_census_df.columns)} columns and {len(self.master_census_df)} rows")
        self.master_census_df = self.combine_address_fields(self.master_census_df)

    # Combine Address columns into "Member Street Address"
    def combine_address_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        address_cols = [col for col in df.columns if re.match(r'address[\s_]*\d*', col, re.IGNORECASE)]
        if len(address_cols) > 1 or (
            len(address_cols) == 1 and address_cols[0].lower() != 'member street address'
        ):
            address_cols_sorted = sorted(address_cols, key=lambda x: int(re.sub(r'\D', '', x) or 0))
            df['Member Street Address'] = df[address_cols_sorted].fillna('').astype(str).agg(' '.join, axis=1).str.replace(r'\s+', ' ', regex=True).str.strip()
            for col in address_cols:
                if col != 'Member Street Address':
                    df = df.drop(col, axis=1)
        return df

    def match_columns(self, df: pd.DataFrame, required_columns: list) -> dict:
        column_mapping = {}
        existing_columns = df.columns.tolist()

        # 1. "COV" logic: map any Coverage Type fields
        for req_col in required_columns:
            if req_col.upper().endswith("COVERAGE TYPE"):
                coverage_type = req_col.split()[0].upper()
                for ex_col in existing_columns:
                    ex_col_upper = ex_col.upper()
                    if "COV" in ex_col_upper and coverage_type in ex_col_upper:
                        column_mapping[req_col] = ex_col

        # 2. Custom aliases
        custom_aliases = {
            "Dental Plan Election": [
                "DENTAL PLAN SELECTION", "DEN PLN", "DENTAL ELECTION"
            ],
            "Vision Plan Election": [
                "VISION PLAN SELECTION", "VIS PLN", "VISION ELECTION"
            ],
            "Zip": [
                "ZIP CODE", "POSTAL CODE", "ZIPCODE", "ZIP"
            ],
            "Employee Vol Life": [
                "EMPLOYEE VOLUNTARY LIFE", "EE VOL LIFE", "EE VLIFE",
                "EMPLOYEE VOLUNTARY LIFE INSURANCE FLAT AMOUNT VOLUME",
                "EMPLOYEE VOLUME AMOUNT"
            ],
            "Spouse Vol Life": [
                "SPOUSE VOLUNTARY LIFE", "SPOUSAL VOLUNTARY LIFE", "SP VOL LIFE",
                "SP VLIFE", "SPOUSE VOLUNTARY LIFE INSURANCE FLAT AMOUNT VOLUME",
                "SPOUSE VOLUME AMOUNT"
            ],
            "Dependent Vol Life": [
                "DEPENDENT VOLUNTARY LIFE", "DEPENDENT VOL LIFE", "DEP VLIFE",
                "CH VOL LIFE", "CH VLIFE", "DEPENDENT CHILD VOLUNTARY LIFE INSURANCE FLAT AMOUNT VOLUME",
                "DEPENDENT"
            ],
            "Hours Worked": [
                "HOURS WORKED PER WEEK", "HOURS WORKED"
            ]
        }

        for required, aliases in custom_aliases.items():
            for col in existing_columns:
                col_norm = col.upper().replace(" ", "")
                for alias in aliases:
                    if col_norm == alias.upper().replace(" ", ""):
                        column_mapping[required] = col

        # 3. Standard exact matching
        for req_col in required_columns:
            if req_col in column_mapping:
                continue
            for ex_col in existing_columns:
                if req_col.lower() == ex_col.lower():
                    column_mapping[req_col] = ex_col
                    break

        # 4. Partial/similarity matching
        unmapped_required = [col for col in required_columns if col not in column_mapping]
        for req_col in unmapped_required:
            best_match = None
            best_score = 0
            req_col_clean = req_col.lower().replace(' ', '')
            for ex_col in existing_columns:
                if ex_col in column_mapping.values():
                    continue
                ex_col_clean = ex_col.lower().replace(' ', '')
                if req_col_clean in ex_col_clean or ex_col_clean in req_col_clean:
                    common_len = len(set(req_col_clean) & set(ex_col_clean))
                    max_len = max(len(req_col_clean), len(ex_col_clean))
                    score = common_len / max_len if max_len > 0 else 0
                    if score > best_score:
                        best_score = score
                        best_match = ex_col
            if best_match and best_score > 0.5:
                column_mapping[req_col] = best_match

        return column_mapping

    def ask_user_for_column_mapping(self, df: pd.DataFrame, required_columns: list, auto_mapping: dict) -> dict:
        final_mapping = auto_mapping.copy()
        existing_columns = df.columns.tolist()
        available_columns = [col for col in existing_columns if col not in auto_mapping.values()]
        unmapped_required = [col for col in required_columns if col not in auto_mapping]

        while unmapped_required and available_columns:
            print("\nOutstanding required columns to match (by Letter):")
            req_letters = {}
            for i, req_col in enumerate(unmapped_required):
                letter = excel_col_label(i)
                req_letters[letter] = req_col
                print(f"  {letter}. {req_col}")

            print("\nAvailable columns in your data (by Number):")
            col_numbers = {}
            for i, av_col in enumerate(available_columns):
                number = str(i + 1)
                col_numbers[number] = av_col
                preview = df[av_col].dropna().head(2).tolist()
                preview_str = ", ".join(str(x) for x in preview) if preview else "No data"
                print(f"  {number}. {av_col} (Sample: {preview_str})")

            print("\nTo map, enter pairs like 1A,2E,3B (NumberLetter for ColNum -> Required). Enter 0 to skip mapping.")
            entry = input("Your mapping: ").replace(' ', '').upper()

            if entry == '0' or entry == '':
                break

            mappings = entry.split(',')
            for mapping in mappings:
                if len(mapping) < 2:
                    continue
                col_num, req_letter = mapping[:-1], mapping[-1]
                if col_num in col_numbers and req_letter in req_letters:
                    req_col = req_letters[req_letter]
                    av_col = col_numbers[col_num]
                    final_mapping[req_col] = av_col

            available_columns = [col for col in existing_columns if col not in final_mapping.values()]
            unmapped_required = [col for col in required_columns if col not in final_mapping]

        return final_mapping

    def process_master_census(self) -> pd.DataFrame:
        auto_mapping = self.match_columns(self.master_census_df, self.FLAT_MASTER_CENSUS_COLUMNS)
        print("\nAutomatically mapped MASTER CENSUS columns:")
        for req_col, ex_col in auto_mapping.items():
            print(f"  {req_col} -> {ex_col}")
        final_mapping = self.ask_user_for_column_mapping(
            self.master_census_df, self.FLAT_MASTER_CENSUS_COLUMNS, auto_mapping
        )
        self.column_mapping = final_mapping
        processed_df = self.master_census_df.copy()
        for req_col, ex_col in final_mapping.items():
            processed_df[ex_col] = self.clean_column(processed_df[ex_col], req_col)

        rename_dict = {
            'Employee Volume Amount': 'Employee Vol Life',
            'Spouse Volume Amount': 'Spouse Vol Life',
            'Dependent': 'Dependent Vol Life'
        }
        processed_df = processed_df.rename(columns=rename_dict)

        for req_col in self.FLAT_MASTER_CENSUS_COLUMNS:
            if req_col not in processed_df.columns:
                processed_df[req_col] = np.nan if req_col not in [
                    'Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life', 'Hours Worked'
                ] else 0

        processed_df = self.set_default_values(processed_df)
        processed_df = self.validate_data(processed_df)

        for col in ['Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life', 'Hours Worked']:
            if col in processed_df.columns:
                # Convert all blanks and non-numeric to NaN, then fill with 0 and convert to int
                processed_df[col] = pd.to_numeric(processed_df[col], errors='coerce').fillna(0).astype(int)



        ordered_columns = [col for col in self.FLAT_MASTER_CENSUS_COLUMNS if col in processed_df.columns]
        other_columns = [col for col in processed_df.columns if col not in ordered_columns]
        processed_df = processed_df[ordered_columns + other_columns]
        return processed_df

    def clean_column(self, series: pd.Series, column_name: str) -> pd.Series:
        if series.dtype != 'object':
            series = series.astype(str)
        series = series.fillna('')

        if column_name in ['Member Last Name', 'First Name', 'City']:
            series = series.str.upper().str.replace(r'[^\w\s]', '', regex=True).str.strip()
            if column_name == 'Member Last Name':
                series = series.str.replace('-', ' ')
        elif column_name == 'Middle Initial':
            series = series.str.upper().str.strip()
            series = series.apply(lambda x: x[0] if x and len(x) > 0 else '')
        elif column_name == 'Gender':
            series = series.str.upper().str.strip()
            series = series.apply(lambda x: 'M' if x in ['M', 'MALE'] else ('F' if x in ['F', 'FEMALE'] else ''))
        elif column_name in ['Date of Birth', 'Date of Hire', 'Dental Prior Carrier Effective Date', 'Dental Prior Carrier Term Date']:
            series = series.apply(self.format_date)
        elif column_name == 'Social Security Number':
            series = series.str.replace(r'\D', '', regex=True)
            series = series.apply(lambda x: x if len(x) == 9 else '')
        elif column_name == 'Member Street Address':
            series = series.str.upper().str.strip()
            series = series.str.replace('#', ' UNIT ')
            for full, abbr in self.USPS_ABBREVIATIONS.items():
                series = series.str.replace(r'\b' + full + r'\b', abbr, regex=True)
        elif column_name == 'State':
            series = series.str.upper().str.strip()
            series = series.apply(lambda x: x if len(x) == 2 else '')
        elif column_name == 'Zip':
            series = series.str.replace(r'\D', '', regex=True)
            series = series.apply(lambda x: x[:5] if len(x) >= 5 else x)
        elif column_name == 'Phone':
            series = series.str.replace(r'\D', '', regex=True)
            series = series.apply(lambda x: x if len(x) == 10 else '')
        elif column_name in self.VALID_VALUES:
            valid_values = self.VALID_VALUES[column_name]
            series = series.apply(lambda x: self.standardize_categorical(x, valid_values))
        return series

    def format_date(self, date_str: str) -> str:
        if not date_str:
            return ''
        try:
            if isinstance(date_str, (datetime, pd.Timestamp)):
                date_obj = date_str
            else:
                date_str = re.sub(r'[^\d/-]', '', str(date_str))
                for fmt in ['%m/%d/%Y', '%m-%d-%Y', '%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y', '%d-%m-%Y']:
                    try:
                        date_obj = datetime.strptime(date_str, fmt)
                        break
                    except ValueError:
                        continue
                else:
                    try:
                        date_obj = pd.to_datetime(date_str)
                    except:
                        return ''
            return date_obj.strftime('%m/%d/%Y')
        except:
            return ''

    def standardize_categorical(self, value: str, valid_values: list) -> str:
        if not value:
            return ''
        value_upper = value.upper().strip()
        for valid in valid_values:
            if value_upper == valid.upper():
                return valid
        for valid in valid_values:
            if valid.upper() in value_upper or value_upper in valid.upper():
                return valid
        if 'Employee' in valid_values:
            if 'EMP' in value_upper:
                return 'Employee'
            elif 'SPO' in value_upper or 'WIFE' in value_upper or 'HUSB' in value_upper:
                return 'Spouse'
            elif 'PART' in value_upper:
                return 'Domestic Partner'
            elif 'CHILD' in value_upper or 'SON' in value_upper or 'DAUGH' in value_upper:
                return 'Child'
        if 'M' in valid_values and 'F' in valid_values:
            if 'M' in value_upper or 'MALE' in value_upper:
                return 'M'
            elif 'F' in value_upper or 'FEMALE' in value_upper:
                return 'F'
        if 'Yes' in valid_values and 'No' in valid_values:
            if value_upper in ['Y', 'YES', 'TRUE', '1']:
                return 'Yes'
            elif value_upper in ['N', 'NO', 'FALSE', '0']:
                return 'No'
        if 'EE' in valid_values and 'W' in valid_values:
            if value_upper in ['EE', 'EMPLOYEE', 'SINGLE']:
                return 'EE'
            elif value_upper in ['ES', 'EMPLOYEE SPOUSE', 'EMPLOYEE+SPOUSE']:
                return 'ES'
            elif value_upper in ['EC', 'EMPLOYEE CHILD', 'EMPLOYEE+CHILD']:
                return 'EC'
            elif value_upper in ['EF', 'FAMILY', 'EMPLOYEE+FAMILY']:
                return 'EF'
            elif value_upper in ['W', 'WAIVE', 'WAIVED', 'DECLINE', 'DECLINED']:
                return 'W'
        if 'Annual' in valid_values and 'Hourly' in valid_values:
            if 'ANNUAL' in value_upper or 'SALARY' in value_upper or 'YEAR' in value_upper:
                return 'Annual'
            elif 'HOUR' in value_upper:
                return 'Hourly'
        if 'Active' in valid_values and 'COBRA' in valid_values:
            if 'ACTIVE' in value_upper:
                return 'Active'
            elif 'COBRA' in value_upper:
                return 'COBRA'
            elif 'RETIRE' in value_upper:
                return 'Retiree'
        return ''

    def set_default_values(self, df: pd.DataFrame) -> pd.DataFrame:
        df['Status Field'] = df['Status Field'].astype('object')
        df['Disabled'] = df['Disabled'].astype('object')
        mask = (df['Relationship'] == 'Employee') & (df['Status Field'].isna() | (df['Status Field'] == ''))
        df.loc[mask, 'Status Field'] = 'Active'
        mask = df['Disabled'].isna() | (df['Disabled'] == '')
        df.loc[mask, 'Disabled'] = 'No'
        for col in ['Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life']:
            if col in df.columns:
                mask = df[col].isna() | (df[col] == '') | (df[col] == 'nan')
                df.loc[mask, col] = 0
        if 'Hours Worked' in df.columns:
            mask = df['Hours Worked'].isna() | (df['Hours Worked'] == '') | (df['Hours Worked'] == 'nan')
            df.loc[mask, 'Hours Worked'] = 40
        return df

    def validate_data(self, df: pd.DataFrame) -> pd.DataFrame:
        today = datetime.now()

        def validate_child_age(row):
            if row['Relationship'] == 'Child':
                if row['Date of Birth'] and row['Date of Birth'] != '':
                    try:
                        dob = datetime.strptime(row['Date of Birth'], '%m/%d/%Y')
                        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
                        if age > 25 and row['Disabled'] != 'Yes':
                            print(f"Warning: Child over 25 years old and not marked as disabled: {row['First Name']} {row['Member Last Name']}")
                    except:
                        pass
            return row

        df = df.apply(validate_child_age, axis=1)

        employee_ssns = df[df['Relationship'] == 'Employee']['Social Security Number'].dropna()
        duplicate_ssns = employee_ssns[employee_ssns.duplicated()].unique()
        if len(duplicate_ssns) > 0:
            print(f"Warning: Found {len(duplicate_ssns)} duplicate SSNs for employees")
            for ssn in duplicate_ssns:
                print(f"  Duplicate SSN: {ssn}")

        df['Social Security Number'] = df['Social Security Number'].astype('object')
        df.loc[df['Relationship'] != 'Employee', 'Social Security Number'] = ''

        def validate_term_date(row):
            if row.get('Dental Prior Carrier Term Date') and row['Dental Prior Carrier Term Date'] != '':
                try:
                    term_date = datetime.strptime(row['Dental Prior Carrier Term Date'], '%m/%d/%Y')
                    if term_date < today:
                        print(f"Warning: Dental Prior Carrier Term Date is not a future date: {row['Dental Prior Carrier Term Date']}")
                except:
                    pass
            return row

        df = df.apply(validate_term_date, axis=1)

        benefit_columns = [
            'Dental Plan Election', 'Dental Coverage Type', 'DHMO Provider Name',
            'Dental Prior Carrier Name', 'Dental Prior Carrier Effective Date',
            'Dental Prior Carrier Term Date', 'Dental Prior Carrier Ortho',
            'Vision Plan Election', 'Vision Coverage Type',
            'Basic Life Coverage Type', 'Primary Life Beneficiary',
            'Dependent Basic Life', 'Life/AD&D Class',
            'Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life',
            'STD', 'LTD', 'STD Class', 'LTD Class',
            'Salary Type', 'Salary Amount', 'Occupation', 'Hours Worked',
            'Working Location', 'Billing Division'
        ]
        for col in benefit_columns:
            if col in df.columns:
                if col in ['Employee Vol Life', 'Spouse Vol Life', 'Dependent Vol Life']:
                    df.loc[df['Relationship'] != 'Employee', col] = 0
                elif pd.api.types.is_numeric_dtype(df[col]):
                    df.loc[df['Relationship'] != 'Employee', col] = np.nan
                else:
                    df.loc[df['Relationship'] != 'Employee', col] = ''

        df['Date of Hire'] = df['Date of Hire'].astype('object')
        df.loc[df['Relationship'] != 'Employee', 'Date of Hire'] = ''
        return df

    def save_processed_file(self, output_path: str) -> None:
        # Defensive check for invalid output paths
        print(f"\n[DEBUG] About to save output to: {output_path}")
        if not output_path or os.path.basename(output_path).upper() == "PRN":
            raise ValueError("Output path cannot be empty or 'PRN'. Please check your input/output file names.")
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            self.processed_master_census.to_excel(writer, sheet_name='MASTER CENSUS', index=False)
        print(f"\nProcessed file saved to: {output_path}")


    def process(self) -> bool:
        try:
            if not self.load_excel_file():
                return False
            master_census_sheet = self.analyze_sheets()
            self.load_sheet(master_census_sheet)
            # combine_address_fields is already called in load_sheet
            self.processed_master_census = self.process_master_census()
            base_name = os.path.basename(self.file_path)
            name, ext = os.path.splitext(base_name)
            output_path = os.path.join(os.path.dirname(self.file_path), f"{name}_processed{ext}")
            self.save_processed_file(output_path)
            return True
        except Exception as e:
            print(f"Error processing Excel file: {e}")
            import traceback
            traceback.print_exc()
            return False

def main():
    print("Excel File Processor for Insurance Data (MASTER CENSUS Only)")
    print("======================================")
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = get_file_path_interactive()
        if not file_path:
            print("No file selected. Exiting.")
            return
    processor = ExcelProcessor(file_path)
    success = processor.process()
    if success:
        print("\nProcessing completed successfully!")
    else:
        print("\nProcessing failed. Please check the error messages above.")

if __name__ == "__main__":
    main()
